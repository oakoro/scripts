/*** Truncate BPASessionLog_NonUnicode_Stage table in case previous truncation failed or was delayed ***/
truncate table BPASessionLog_NonUnicode_Stage;
GO

/*** Switch (Move) the data in Partition 2 to the BPASessionLog_NonUnicode_Stage table ***/
ALTER TABLE BPASessionLog_NonUnicode SWITCH PARTITION 2 TO BPASessionLog_NonUnicode_Stage;
GO
/*** Truncate BPASessionLog_NonUnicode_Stage table ***/
truncate table BPASessionLog_NonUnicode_Stage;
GO
