 /****** Object:  Index [PK_BPASessionLog_NonUnicode]    Script Date: 9/7/2022 3:39:45 PM ******/
ALTER TABLE [dbo].[BPASessionLog_NonUnicode] DROP CONSTRAINT [PK_BPASessionLog_NonUnicode] WITH ( ONLINE = OFF )
GO

/*** Create Right Range Partition with 8 Partitions - first and last are empty per best practice and Hold 6 weeks of data ***/ 
CREATE PARTITION FUNCTION pflogid (BIGINT)
AS RANGE Right FOR VALUES (1,2,3,4,5,6,7,2147483647)

/*** Create Schema for the Right Range Partition - this would normally merge the separate tables ***/ 
CREATE PARTITION SCHEME pslogid AS PARTITION pflogid
ALL TO ([PRIMARY])

/****** Recreate PK/Cluster Index Object:  Index [PK_BPASessionLog_NonUnicode]    Script Date: 9/7/2022 3:32:40 PM ******/
ALTER TABLE [dbo].[BPASessionLog_NonUnicode] ADD  CONSTRAINT [PK_BPASessionLog_NonUnicode] PRIMARY KEY CLUSTERED 
(
	[logid] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON pslogid (logid)
GO


